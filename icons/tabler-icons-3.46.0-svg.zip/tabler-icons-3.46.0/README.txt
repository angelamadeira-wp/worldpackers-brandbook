Tabler Icons 3.46.0 — the icon library of the Worldpackers design system.
outline/ 5130 icons   filled/ 1054 icons   total 6184
24x24 grid, 2px stroke, round caps and joins. Stroke is currentColor.
Licence: MIT (Tabler). Vendored in packages/icons of the design system monorepo.
